package LojaVirtual.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import LojaVirtual.com.model.GrupoProduto;

public interface GrupoProdutoRepository extends JpaRepository<GrupoProduto, Long> {

}