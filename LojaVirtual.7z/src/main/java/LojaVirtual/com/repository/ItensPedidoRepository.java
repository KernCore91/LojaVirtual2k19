package LojaVirtual.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import LojaVirtual.com.model.ItensPedido;

public interface ItensPedidoRepository extends JpaRepository<ItensPedido, Long> {

}