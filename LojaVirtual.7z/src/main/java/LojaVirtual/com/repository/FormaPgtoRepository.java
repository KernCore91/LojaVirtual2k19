package LojaVirtual.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import LojaVirtual.com.model.FormaPgto;

public interface FormaPgtoRepository extends JpaRepository<FormaPgto, Long> {

}